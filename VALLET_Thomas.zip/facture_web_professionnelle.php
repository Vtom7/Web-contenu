<?php

$quantité = mt_rand(1,5);

$prix_unité_HT1 = 400;
$prix_unité_HT2 = 200;
$prix_unité_HT3 = 12;

// Total HT ordinateur

function prix_ht1($quantité,$prix_unité_HT1)
{
	$prix_ht1 = $quantité * $prix_unité_HT1;

	return($prix_ht1);
}

// Total HT smartphone

function prix_ht2($quantité,$prix_unité_HT2)
{
	$prix_ht2 = $quantité * $prix_unité_HT2;

	return($prix_ht2);
}

// Total HT livre

function prix_ht3($quantité,$prix_unité_HT3)
{
	$prix_ht3 = $quantité * $prix_unité_HT3;

	return($prix_ht3);
}

// Total HT des produits

$total_ht = prix_ht1($quantité,$prix_unité_HT1) + prix_ht2($quantité,$prix_unité_HT2) + prix_ht3($quantité,$prix_unité_HT3);

// Total TVA 20%

$tva_20 = prix_ht1($quantité,$prix_unité_HT1) - prix_ht2($quantité,$prix_unité_HT2) - prix_ht3($quantité,$prix_unité_HT3);

// Total TCC

$total_ttc = $total_ht + $tva_20;

// Tableau indexé numériquement

$entete = array("Description","Quantité","Unité","Prix unitaire HT","Prix total HT","TVA");

// Tableau multidimensionnel

$info = array(
array(
"description" => "Ordinateur",
"quantité" => $quantité,
"unité" => "octet",
"prix unitaire HT" => $prix_unité_HT1."€",
"prix total HT" => prix_ht1($quantité,$prix_unité_HT1)."€",
"TVA" => "20%"
),
array(
"description" => "Smartphone",
"quantité" => $quantité,
"unité" => "watt/kg",
"prix unitaire HT" => $prix_unité_HT2."€",
"prix total HT" => prix_ht2($quantité,$prix_unité_HT2)."€",
"TVA" => "20%"
),
array(
"description" => "Livre",
"quantité" => $quantité,
"unité" => "g",
"prix unitaire HT" => $prix_unité_HT3."€",
"prix total HT" => prix_ht1($quantité,$prix_unité_HT3)."€",
"TVA" => "20%"
)
);

// Tableau indexé numériquement

$resultat = array("Total HT","TVA 20%","Total TVA","Total TTC");

// Tableau multidimensionnel

$res = array(
array(
"total ht" => $total_ht.",00€",
"tva20%" => $tva_20.",00€",
"totaltva" => $total_ht.",00€",
"totalttc" => $total_ttc.",00€"
)
);

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="facture_web_professionnelle.css">
	<link rel="icon" href="https://logo-marque.com/wp-content/uploads/2021/03/Fnac-Logo.png">
	<title>Facture Web Professionnelle</title>
</head>
<body>
	<header>
    	<div class="entreprise">
    	<a href="#"><img src="https://logo-marque.com/wp-content/uploads/2021/03/Fnac-Logo.png" alt="logo-fnac" style="width:200px;height:100px;"></a>
    	<h2>Client :<br>
    	Monsieur Pierre VELON</h2>
    	</div>
    	<br>
    	<b>FNAC<br>
    	2 Av. du Général de Gaulle,<br>
    	93117 Rosny-sous-Bois<br>
    	SIRET : 219 300 647 00019<br>
    	Tél : 0 825 02 00 20<br>
    	E-Mail : rosny2@fnac.tm.fr</b>
	</header>
	<h1>Facture Web Professionnelle n°1<br>
	Date : 31/01/2023</h1>

	<br><br>

	<table>
			<tr>
				<th><?php echo($entete[0]); ?></th>
				<th><?php echo($entete[1]); ?></th>
				<th><?php echo($entete[2]); ?></th>
				<th><?php echo($entete[3]); ?></th>
				<th><?php echo($entete[4]); ?></th>
				<th><?php echo($entete[5]); ?></th>
			</tr>
			<?php
			
			for ($i = 0; $i < count($info); $i++)
			{
			
			?>
			<tr>
				<td><?php echo($info[$i]["description"]); ?></td>
				<td><?php echo($info[$i]["quantité"]); ?></td>
				<td><?php echo($info[$i]["unité"]); ?></td>
				<td><?php echo($info[$i]["prix unitaire HT"]); ?></td>
				<td><?php echo($info[$i]["prix total HT"]); ?></td>
				<td><?php echo($info[$i]["TVA"]); ?></td>
			</tr>
			<?php
			
			}
			
			?>
		</table>

		<br><br>

		<table class="exemple">
			<tr>
				<th width="115px"><?php echo($resultat[0]); ?></th>
			<?php
			
			for ($i = 0; $i < count($res); $i++)
			{
			
			?>
				<td width="115px"><?php echo($res[$i]["total ht"]); ?></td>
			</tr>
				<th><?php echo($resultat[1]); ?></th>
				<td><?php echo($res[$i]["tva20%"]); ?></td>
			</tr>
				<th><?php echo($resultat[2]); ?></th>
				<td><?php echo($res[$i]["totaltva"]); ?></td>
			</tr>
				<th><?php echo($resultat[3]); ?></th>
				<td class="ttc"><?php echo("<b><font color=white>".$res[$i]["totalttc"]."</font></b>"); ?></td>
			</tr>
			<?php
			
			}
			
			?>
		</table>

		<br><br>

		<p>Conditions de paiement : 60% à la commande, paiement à réception de facture<br>
		Mode de paiement : par virement ou chèque</p>
		<p>Nous vous remercions de votre confiance.</p>
		<p>Cordialement</p>
</body>
</html>