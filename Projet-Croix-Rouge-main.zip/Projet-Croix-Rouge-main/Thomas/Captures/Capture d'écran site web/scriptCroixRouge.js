const button = document.querySelector('#button-id');

button.addEventListener('click', function() {
 
  document.article.style.background = color;
 
};