/*Sélection de tous les liens du menu principal, classés par ordre d’affichage*/

select menu_nom
from menu
order by menu_nom asc;

/*Sélection de tous les liens du sous-menu « Produits »*/

select lien_nom
from lien,sous-menu
where sous-menu_nom = 'Produits';
and lien.id_lien = sous-menu.id_lien;

/*Sélection de tous les liens qui commencent par la lettre « A »*/

select lien_nom
from lien
where lien_nom like 'A%';

/*Sélection de tous les liens externes qui ouvrent un nouvel onglet*/

select categorie_nom
from categorie,lien
where categorie_nom = 'externe'
and categorie.id_categorie = lien.id_categorie;

/*Sélection des liens qui ne contiennent pas l’extension « php »*/

select lien_nom
from lien
where id_lien not in (select id_lien from extension);