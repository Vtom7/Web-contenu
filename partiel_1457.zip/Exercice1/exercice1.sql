#------------------------------------------------------------
#        Script MySQL.
#------------------------------------------------------------


#------------------------------------------------------------
# Table: categorie
#------------------------------------------------------------

CREATE TABLE categorie(
        id_categorie  Int  Auto_increment  NOT NULL ,
        categorie_nom Varchar (50) NOT NULL
	,CONSTRAINT categorie_PK PRIMARY KEY (id_categorie)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: plat
#------------------------------------------------------------

CREATE TABLE plat(
        id_plat      Int  Auto_increment  NOT NULL ,
        plat_nom     Varchar (50) NOT NULL ,
        plat_prix    Float NOT NULL ,
        id_categorie Int NOT NULL
	,CONSTRAINT plat_PK PRIMARY KEY (id_plat)

	,CONSTRAINT plat_categorie_FK FOREIGN KEY (id_categorie) REFERENCES categorie(id_categorie)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: restaurant
#------------------------------------------------------------

CREATE TABLE restaurant(
        id_restauant   Int  Auto_increment  NOT NULL ,
        restaurant_nom Varchar (50) NOT NULL ,
        id_plat        Int NOT NULL
	,CONSTRAINT restaurant_PK PRIMARY KEY (id_restauant)

	,CONSTRAINT restaurant_plat_FK FOREIGN KEY (id_plat) REFERENCES plat(id_plat)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: commande
#------------------------------------------------------------

CREATE TABLE commande(
        id_commande     Int  Auto_increment  NOT NULL ,
        commande_nom    Varchar (50) NOT NULL ,
        commande_prenom Varchar (50) NOT NULL ,
        commande_date   Date NOT NULL ,
        id_plat         Int NOT NULL
	,CONSTRAINT commande_PK PRIMARY KEY (id_commande)

	,CONSTRAINT commande_plat_FK FOREIGN KEY (id_plat) REFERENCES plat(id_plat)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: utilisateur
#------------------------------------------------------------

CREATE TABLE utilisateur(
        id_utilisateur       Int  Auto_increment  NOT NULL ,
        utilisateur_civilite Varchar (50) NOT NULL ,
        utilisateur_nom      Varchar (50) NOT NULL ,
        utilisateur_prenom   Varchar (50) NOT NULL ,
        utilisateur_mail     Varchar (50) NOT NULL ,
        id_commande          Int NOT NULL
	,CONSTRAINT utilisateur_PK PRIMARY KEY (id_utilisateur)

	,CONSTRAINT utilisateur_commande_FK FOREIGN KEY (id_commande) REFERENCES commande(id_commande)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: administration
#------------------------------------------------------------

CREATE TABLE administration(
        id_administration  Int  Auto_increment  NOT NULL ,
        administration_nom Varchar (50) NOT NULL ,
        id_restauant       Int NOT NULL ,
        id_utilisateur     Int NOT NULL
	,CONSTRAINT administration_PK PRIMARY KEY (id_administration)

	,CONSTRAINT administration_restaurant_FK FOREIGN KEY (id_restauant) REFERENCES restaurant(id_restauant)
	,CONSTRAINT administration_utilisateur0_FK FOREIGN KEY (id_utilisateur) REFERENCES utilisateur(id_utilisateur)
)ENGINE=InnoDB;