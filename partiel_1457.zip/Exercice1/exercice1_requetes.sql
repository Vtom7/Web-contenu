/*Sélection de tous les noms de plats, classés par prix décroissant*/

select plat_nom
from plat
order by plat_prix desc;

/*Sélection de toutes les catégories représentées par au moins un plat*/

select *
from categorie,plat
where categorie.id_categorie = plat.id_categorie;

/*Sélection des noms et prénoms des utilisateurs ayant une adresse en « gmail.com »*/

select utilisateur_nom,utilisateur_prenom
from utilisateur
where utilisateur_mail = 'gmail.com';

/*Sélection de toutes les commandes du jeudi 18 mai 2023, classées par nom et prénom d’utilisateur*/

select *
from commande,utilisateur
where commande_date = 'jeudi 18 mai 2023'
and commande.id_commande = utilisateur.id_commande
order by utilisateur_nom,utilisateur_prenom;

/*Sélection des noms d’utilisateurs qui n’ont jamais commandé sur le site*/

select utilisateur_nom
from utilisateur
where id_utilisateur not in (select id_utilisateur from commande);

/*Sélection des noms d’utilisateur s’étant connectés plus de 5 fois, ayant au moins fait une commande d’un dessert*/

select utilisateur_nom
from utilisateur,commande,plat,categorie
where utilisateur_mail >= 5
and categorie_nom = 'dessert'
and utilisateur.id_commande = commande.id_commande
and commande.id_plat = plat.id_plat
and plat.id_categorie = categorie.id_categorie;

/*Sélection des catégories de plat ayant été commandées le jeudi 18 mai 2023, pour des prix de plats supérieurs à 20 euros*/

select categorie_nom
from categorie,plat,commande
where commande_date = 'jeudi 18 mai 2023'
and plat_prix >= 20
and commande.id_plat = plat.id_plat
and plat.id_categorie = categorie.id_categorie;

/*Sélection des noms d’utilisateurs ayant commandé une pizza mais pas un dessert*/

select utilisateur_nom
from utilisateur,commande,plat,catégorie
where categorie_nom = 'pizza'
and id_utilisateur not in
(select id_utilisateur
from utilisateur,commande,plat,categorie
where categorie_nom = 'dessert'
and utilisateur.id_commande = commande.id_commande
and commande.id_plat = plat.id_plat
and plat.id_categorie = categorie.id_categorie);

/*Sélection de toutes les entrées qui n’ont pas encore de photos et dont le prix est inférieur à 5 euros*/

select categorie_nom
from categorie,plat
where categorie_nom = 'dessert'
and plat_prix < 5
and categorie.id_categorie = plat.id_categorie;

/*Ajout complet des propriétés d’une pizza de votre choix*/

insert into categorie value(NULL,'pizza');